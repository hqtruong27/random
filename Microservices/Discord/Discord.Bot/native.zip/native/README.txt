When use window or window server
 - change name libopus.dll -> opus.dll
 - and paste opus.dll, libsodium.dll, ffmpeg.exe, yt-dlp.exe(optional) to publish folder